const gConfig = {}
export const fieldFormConfig = {
  itemWidth: 24,
  input: {
    items: [
      {
        field: 'field',
        title: '绑定字段',
      },
    ],
  },
}
