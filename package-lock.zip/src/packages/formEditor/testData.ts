// export const staticData = {
//   "list": [
//     {
//       "type": "inline",
//       "columns": [
//         {
//           "type": "tabs",
//           "label": "Tabs",
//           "icon": "label",
//           "id": "HUCtMk8X91tdT85ciDvJO",
//           "columns": [
//             {
//               "id": "jP77IPLOou4mHu0jiuTdT",
//               "type": "tabsCol",
//               "label": "Tab 1",
//               "list": [
//                 {
//                   "type": "inline",
//                   "columns": [
//                     "YZ6AbijFGwODTzK160CyH"
//                   ],
//                   "style": {},
//                   "id": "jGwptrUfUgPf3U57vPUWz",
//                   "key": "inline_jGwptrUfUgPf3U57vPUWz"
//                 }
//               ],
//               "style": {},
//               "options": {},
//               "key": "tabsCol_jP77IPLOou4mHu0jiuTdT"
//             },
//             {
//               "id": "igO656XKpoovgvIfLWQOd",
//               "type": "tabsCol",
//               "label": "Tab 2",
//               "list": [
//                 {
//                   "type": "inline",
//                   "columns": [
//                     "08QOcZmxIplHk8UrQLciY"
//                   ],
//                   "style": {},
//                   "id": "9A2H8bk3i35GLKdvevpei",
//                   "key": "inline_9A2H8bk3i35GLKdvevpei"
//                 }
//               ],
//               "style": {},
//               "options": {},
//               "key": "tabsCol_igO656XKpoovgvIfLWQOd"
//             },
//             {
//               "id": "4IOUwfF6ichmcZwlb6IH3",
//               "type": "tabsCol",
//               "label": "Tab 3",
//               "list": [
//                 {
//                   "type": "inline",
//                   "columns": [
//                     "pm_5e3mEn8wJ9QhNoVhfe"
//                   ],
//                   "style": {},
//                   "id": "HHMOJWUIdJVd6I9o40aCd",
//                   "key": "inline_HHMOJWUIdJVd6I9o40aCd"
//                 }
//               ],
//               "style": {},
//               "options": {},
//               "key": "tabsCol_4IOUwfF6ichmcZwlb6IH3"
//             }
//           ],
//           "options": {
//             "type": "",
//             "tabPosition": "top",
//             "align": "top",
//             "hidden": false,
//             "defaultValue": "4IOUwfF6ichmcZwlb6IH3"
//           },
//           "style": {
//             "width": "100%"
//           },
//           "key": "tabs_HUCtMk8X91tdT85ciDvJO"
//         }
//       ],
//       "style": {},
//       "id": "lATtZ9aVZ2qFWh3t4A9v4",
//       "key": "inline_lATtZ9aVZ2qFWh3t4A9v4"
//     },
//     {
//       "type": "inline",
//       "columns": [
//         "mPR06A7MgRZ10AO3APc4m"
//       ],
//       "style": {},
//       "id": "yWV4qGC8ndy1pM4FK109C",
//       "key": "inline_yWV4qGC8ndy1pM4FK109C"
//     },
//     {
//       "type": "inline",
//       "columns": [
//         "iuy-gDqekYuIQwBDL_-Jy"
//       ],
//       "style": {},
//       "id": "uG6jO1DisKSVq8-BE6ne8",
//       "key": "inline_uG6jO1DisKSVq8-BE6ne8"
//     }
//   ],
//   "config": {
//     "isSync": true,
//     "pc": {
//       "size": "default",
//       "labelPosition": "left",
//       "completeButton": {
//         "text": "提交",
//         "color": "",
//         "backgroundColor": ""
//       }
//     },
//     "mobile": {
//       "labelPosition": "left",
//       "completeButton": {
//         "text": "提交",
//         "color": "",
//         "backgroundColor": ""
//       }
//     }
//   },
//   "fields": [
//     {
//       "type": "rate",
//       "label": "Rate",
//       "icon": "rating",
//       "key": "rate_YZ6AbijFGwODTzK160CyH",
//       "id": "YZ6AbijFGwODTzK160CyH",
//       "options": {
//         "max": 5,
//         "allowHalf": false,
//         "defaultValue": 0,
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "disabled": false
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "radio",
//       "label": "Radio",
//       "icon": "radio",
//       "key": "radio_08QOcZmxIplHk8UrQLciY",
//       "id": "08QOcZmxIplHk8UrQLciY",
//       "options": {
//         "dataKey": "08QOcZmxIplHk8UrQLciY",
//         "displayStyle": "block",
//         "defaultValue": "",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "disabled": false,
//         "required": false,
//         "otherPlaceholder": "Please enter additional information"
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "textarea",
//       "label": "Textarea",
//       "icon": "textarea",
//       "key": "textarea_pm_5e3mEn8wJ9QhNoVhfe",
//       "id": "pm_5e3mEn8wJ9QhNoVhfe",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "rows": 6,
//         "defaultValue": "",
//         "placeholder": "Please enter",
//         "disabled": false,
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "time",
//       "label": "Time",
//       "icon": "time",
//       "key": "time_mPR06A7MgRZ10AO3APc4m",
//       "id": "mPR06A7MgRZ10AO3APc4m",
//       "options": {
//         "clearable": true,
//         "format": "HH:mm:ss",
//         "valueFormat": "HH:mm:ss",
//         "defaultValue": null,
//         "placeholder": "Please select",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "disabled": false
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "date",
//       "label": "Date",
//       "icon": "calendar",
//       "key": "date_iuy-gDqekYuIQwBDL_-Jy",
//       "id": "iuy-gDqekYuIQwBDL_-Jy",
//       "options": {
//         "isShowWordLimit": false,
//         "clearable": true,
//         "format": "YYYY-MM-DD",
//         "defaultValue": null,
//         "startTime": null,
//         "endTime": null,
//         "placeholder": "Please select",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "type": "date",
//         "required": false,
//         "disabled": false
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     }
//   ],
//   "data": {
//     "08QOcZmxIplHk8UrQLciY": {
//       "type": "radio",
//       "list": [
//         {
//           "label": "Option1",
//           "value": "1dAUJOD0OAyIasGpbk-WZ"
//         },
//         {
//           "label": "Option2",
//           "value": "yiJMgjhpOitslvZF7dpMK"
//         },
//         {
//           "label": "Option3",
//           "value": "sxpCNALiraVmQm-BQhgP2"
//         }
//       ]
//     }
//   }
// }


// export const  staticData={
//   "layout": {
//     "pc": [
//       {
//         "type": "inline",
//         "columns": [
//           "jz-jFeyQbpOlqlGaT62Yn"
//         ],
//         "style": {},
//         "id": "-YEzHQ6GE5w_d6RlQfbb4",
//         "key": "inline_-YEzHQ6GE5w_d6RlQfbb4"
//       },
//       {
//         "type": "inline",
//         "columns": [
//           {
//             "type": "grid",
//             "label": "栅格布局",
//             "icon": "grid",
//             "id": "WTts2Dpb5xt0PsuLPut_S",
//             "columns": [
//               {
//                 "id": "WBWNQEyo26_QGFxffo682",
//                 "options": {
//                   "span": 6,
//                   "offset": 0,
//                   "pull": 0,
//                   "push": 0
//                 },
//                 "type": "col",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       "FeJPCv469iDGSkEyUMEcF"
//                     ],
//                     "style": {},
//                     "id": "4aLQSJ9sNDtpU6ExrB05K",
//                     "key": "inline_4aLQSJ9sNDtpU6ExrB05K"
//                   }
//                 ],
//                 "style": {},
//                 "key": "col_WBWNQEyo26_QGFxffo682"
//               },
//               {
//                 "id": "RJCEU2emOGD-KsehOoqSz",
//                 "options": {
//                   "span": 6,
//                   "offset": 0,
//                   "pull": 0,
//                   "push": 0
//                 },
//                 "type": "col",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       "zEGo2Rb3Rmx3RlwVKFc11"
//                     ],
//                     "style": {},
//                     "id": "KocIhaLukSTddkKB_PXwn",
//                     "key": "inline_KocIhaLukSTddkKB_PXwn"
//                   }
//                 ],
//                 "style": {},
//                 "key": "col_RJCEU2emOGD-KsehOoqSz"
//               },
//               {
//                 "id": "rtdtirjxCAgDG5-CYvvwp",
//                 "options": {
//                   "span": 6,
//                   "offset": 0,
//                   "pull": 0,
//                   "push": 0
//                 },
//                 "type": "col",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       {
//                         "type": "grid",
//                         "label": "栅格布局",
//                         "icon": "grid",
//                         "id": "A164WbSwVGj3ReYFnPXSK",
//                         "columns": [
//                           {
//                             "id": "S-FTdaIejCQ6d5HR3-bhD",
//                             "options": {
//                               "span": 6,
//                               "offset": 0,
//                               "pull": 0,
//                               "push": 0
//                             },
//                             "type": "col",
//                             "list": [
//                               {
//                                 "type": "inline",
//                                 "columns": [
//                                   "lYmtIAM6LPQXfBrohAur-"
//                                 ],
//                                 "style": {},
//                                 "id": "opoCMOT4JkpcmW6yNHW7M",
//                                 "key": "inline_opoCMOT4JkpcmW6yNHW7M"
//                               }
//                             ],
//                             "style": {},
//                             "key": "col_S-FTdaIejCQ6d5HR3-bhD"
//                           },
//                           {
//                             "id": "LMai6cMHRdIK9jX6R255O",
//                             "options": {
//                               "span": 6,
//                               "offset": 0,
//                               "pull": 0,
//                               "push": 0
//                             },
//                             "type": "col",
//                             "list": [],
//                             "style": {},
//                             "key": "col_LMai6cMHRdIK9jX6R255O"
//                           },
//                           {
//                             "id": "boRhQHvI-2AilNiNFp0CZ",
//                             "options": {
//                               "span": 6,
//                               "offset": 0,
//                               "pull": 0,
//                               "push": 0
//                             },
//                             "type": "col",
//                             "list": [],
//                             "style": {},
//                             "key": "col_boRhQHvI-2AilNiNFp0CZ"
//                           }
//                         ],
//                         "options": {
//                           "gutter": 0,
//                           "justify": "space-around",
//                           "align": "top"
//                         },
//                         "style": {
//                           "width": "100%"
//                         },
//                         "key": "grid_A164WbSwVGj3ReYFnPXSK"
//                       }
//                     ],
//                     "style": {},
//                     "id": "OMI3rVVjZcQuydZKbtz1N",
//                     "key": "inline_OMI3rVVjZcQuydZKbtz1N"
//                   }
//                 ],
//                 "style": {},
//                 "key": "col_rtdtirjxCAgDG5-CYvvwp"
//               }
//             ],
//             "options": {
//               "gutter": 0,
//               "justify": "space-around",
//               "align": "top"
//             },
//             "style": {
//               "width": "100%"
//             },
//             "key": "grid_WTts2Dpb5xt0PsuLPut_S"
//           }
//         ],
//         "style": {},
//         "id": "smK4g3vK_hUD2fvcQvgzI",
//         "key": "inline_smK4g3vK_hUD2fvcQvgzI"
//       },
//       {
//         "type": "inline",
//         "columns": [
//           {
//             "type": "tabs",
//             "label": "标签页",
//             "icon": "label",
//             "id": "mwF3S5DShJlMuwxziD5F7",
//             "columns": [
//               {
//                 "id": "dbcZTCD9ssekQQskXsDZ3",
//                 "type": "tabsCol",
//                 "label": "Tab 1",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       "NiNhZrZLVVNGCkDOsfPuZ"
//                     ],
//                     "style": {},
//                     "id": "SqHzJBrcU6Tcw0RqEUJ1z",
//                     "key": "inline_SqHzJBrcU6Tcw0RqEUJ1z"
//                   }
//                 ],
//                 "style": {},
//                 "options": {},
//                 "key": "tabsCol_dbcZTCD9ssekQQskXsDZ3"
//               },
//               {
//                 "id": "Kt7Gr2sITXgCHPLpxj7sk",
//                 "type": "tabsCol",
//                 "label": "Tab 2",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       "D_02PxQAH9wLOS_ChXI3M"
//                     ],
//                     "style": {},
//                     "id": "48Ya8bcSUvBlLcgEGNzyF",
//                     "key": "inline_48Ya8bcSUvBlLcgEGNzyF"
//                   }
//                 ],
//                 "style": {},
//                 "options": {},
//                 "key": "tabsCol_Kt7Gr2sITXgCHPLpxj7sk"
//               },
//               {
//                 "id": "DZ4_5kbb4qOjt5cEYmv3N",
//                 "type": "tabsCol",
//                 "label": "Tab 3",
//                 "list": [
//                   {
//                     "type": "inline",
//                     "columns": [
//                       "mKclRWzctBs61JAs0u0W4"
//                     ],
//                     "style": {},
//                     "id": "_UGKTRF54w2rkhPUAWfDt",
//                     "key": "inline__UGKTRF54w2rkhPUAWfDt"
//                   }
//                 ],
//                 "style": {},
//                 "options": {},
//                 "key": "tabsCol_DZ4_5kbb4qOjt5cEYmv3N"
//               }
//             ],
//             "options": {
//               "type": "",
//               "tabPosition": "top",
//               "align": "top",
//               "hidden": false,
//               "defaultValue": "DZ4_5kbb4qOjt5cEYmv3N"
//             },
//             "style": {
//               "width": "100%"
//             },
//             "key": "tabs_mwF3S5DShJlMuwxziD5F7"
//           }
//         ],
//         "style": {},
//         "id": "5DBKyVE-94vHiFZ31_ys3",
//         "key": "inline_5DBKyVE-94vHiFZ31_ys3"
//       },
//       {
//         "type": "inline",
//         "columns": [
//           {
//             "type": "divider",
//             "label": "分割线",
//             "icon": "divider",
//             "key": "divider_BqFr3n-WSdMu3xDz_LJiU",
//             "id": "BqFr3n-WSdMu3xDz_LJiU",
//             "options": {
//               "contentPosition": "center",
//               "filterable": true,
//               "defaultValue": "divider",
//               "labelWidth": 100,
//               "labelHidden": true,
//               "required": false
//             },
//             "style": {
//               "width": "100%"
//             }
//           }
//         ],
//         "style": {},
//         "id": "9OnmY1aojzDIAV-Zq4OdM",
//         "key": "inline_9OnmY1aojzDIAV-Zq4OdM"
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "Ewo6DIJo2lpVQUuMCdBgV"
//         ],
//         "style": {},
//         "id": "dmB9RZiBnOH9E7ssORfE7",
//         "key": "inline_dmB9RZiBnOH9E7ssORfE7"
//       }
//     ],
//     "mobile": [
//       {
//         "type": "inline",
//         "columns": [
//           "jz-jFeyQbpOlqlGaT62Yn"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "FeJPCv469iDGSkEyUMEcF"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "zEGo2Rb3Rmx3RlwVKFc11"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "lYmtIAM6LPQXfBrohAur-"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "NiNhZrZLVVNGCkDOsfPuZ"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "D_02PxQAH9wLOS_ChXI3M"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "mKclRWzctBs61JAs0u0W4"
//         ]
//       },
//       {
//         "type": "inline",
//         "columns": [
//           "Ewo6DIJo2lpVQUuMCdBgV"
//         ]
//       }
//     ]
//   },
//   "data": {
//     "Ewo6DIJo2lpVQUuMCdBgV": {
//       "type": "radio",
//       "list": [
//         {
//           "label": "Option1",
//           "value": "YcEkJWbrjR3MwOp-BaM_E"
//         },
//         {
//           "label": "Option2",
//           "value": "3aGFs89NiBMwwvH_G0nYh"
//         },
//         {
//           "label": "Option3",
//           "value": "cM3Oy6uFOrdxBM5TQFiE2"
//         }
//       ]
//     }
//   },
//   "config": {
//     "isSync": true,
//     "pc": {
//       "size": "default",
//       "labelPosition": "left",
//       "completeButton": {
//         "text": "提交",
//         "color": "",
//         "backgroundColor": ""
//       }
//     },
//     "mobile": {
//       "labelPosition": "left",
//       "completeButton": {
//         "text": "提交",
//         "color": "",
//         "backgroundColor": ""
//       }
//     }
//   },
//   "fields": [
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_jz-jFeyQbpOlqlGaT62Yn",
//       "id": "jz-jFeyQbpOlqlGaT62Yn",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_FeJPCv469iDGSkEyUMEcF",
//       "id": "FeJPCv469iDGSkEyUMEcF",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_zEGo2Rb3Rmx3RlwVKFc11",
//       "id": "zEGo2Rb3Rmx3RlwVKFc11",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_lYmtIAM6LPQXfBrohAur-",
//       "id": "lYmtIAM6LPQXfBrohAur-",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_NiNhZrZLVVNGCkDOsfPuZ",
//       "id": "NiNhZrZLVVNGCkDOsfPuZ",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "input",
//       "label": "单行文本",
//       "icon": "input",
//       "key": "input_D_02PxQAH9wLOS_ChXI3M",
//       "id": "D_02PxQAH9wLOS_ChXI3M",
//       "options": {
//         "clearable": true,
//         "isShowWordLimit": false,
//         "renderType": 1,
//         "disabled": false,
//         "showPassword": false,
//         "defaultValue": "",
//         "placeholder": "请输入",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "required": false,
//         "min": null,
//         "max": null
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "date",
//       "label": "日期",
//       "icon": "calendar",
//       "key": "date_mKclRWzctBs61JAs0u0W4",
//       "id": "mKclRWzctBs61JAs0u0W4",
//       "options": {
//         "isShowWordLimit": false,
//         "clearable": true,
//         "format": "YYYY-MM-DD",
//         "defaultValue": null,
//         "startTime": null,
//         "endTime": null,
//         "placeholder": "请选择",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "type": "date",
//         "required": false,
//         "disabled": false
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     },
//     {
//       "type": "radio",
//       "label": "单选框",
//       "icon": "radio",
//       "key": "radio_Ewo6DIJo2lpVQUuMCdBgV",
//       "id": "Ewo6DIJo2lpVQUuMCdBgV",
//       "options": {
//         "dataKey": "Ewo6DIJo2lpVQUuMCdBgV",
//         "displayStyle": "block",
//         "defaultValue": "",
//         "labelWidth": 100,
//         "isShowLabel": true,
//         "disabled": false,
//         "required": false,
//         "otherPlaceholder": "请输入补充信息"
//       },
//       "style": {
//         "width": {
//           "pc": "100%",
//           "mobile": "100%"
//         }
//       }
//     }
//   ]
// }
export const staticData = {
  "layout": {
    "pc": [
      {
        "type": "inline",
        "columns": [
          {
            "type": "table",
            "label": "表格布局",
            "icon": "tableStokeP2",
            "id": "6CNUjT70zEIhC_fWFtw8z",
            "rows": [
              {
                "type": "tr",
                "columns": [
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "caFRuwlWKZjxx4AbJoSVv"
                        ],
                        "style": {},
                        "id": "52uWJ8p4ba0exHzsSP4iq",
                        "key": "inline_52uWJ8p4ba0exHzsSP4iq"
                      }
                    ],
                    "style": {},
                    "id": "3GJrM4yOTDiDgfsxL92mu",
                    "key": "td_3GJrM4yOTDiDgfsxL92mu"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "7c3j2c97sdqGAPnMqSLA4",
                    "key": "td_7c3j2c97sdqGAPnMqSLA4"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "eJzM3aQ2hwJvt2r_MkJGX",
                    "key": "td_eJzM3aQ2hwJvt2r_MkJGX"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "i1nIAT9_R7uUfscmFYAnL"
                        ],
                        "style": {},
                        "id": "qSiR3l7_PBr4X4slsC9pt",
                        "key": "inline_qSiR3l7_PBr4X4slsC9pt"
                      }
                    ],
                    "style": {},
                    "id": "BIHZscH-BXk1xz5-IGY36",
                    "key": "td_BIHZscH-BXk1xz5-IGY36"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "_2A1xr_iBba-qf6WVBMLp",
                    "key": "td__2A1xr_iBba-qf6WVBMLp"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "8f8EzuK12IzMWjhH6lQ7B",
                    "key": "td_8f8EzuK12IzMWjhH6lQ7B"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "8JTtsbxm4TaWjBtmk4txy"
                        ],
                        "style": {},
                        "id": "Adr2o5qOUP8zt2GmKpwb3",
                        "key": "inline_Adr2o5qOUP8zt2GmKpwb3"
                      }
                    ],
                    "style": {},
                    "id": "FRaPcjM2n76BVrbJbxrAC",
                    "key": "td_FRaPcjM2n76BVrbJbxrAC"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "qBFvlNofTv2ciDvbXiLjU",
                    "key": "td_qBFvlNofTv2ciDvbXiLjU"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "WsaXvZy67W5_m9Ja_tD5_",
                    "key": "td_WsaXvZy67W5_m9Ja_tD5_"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "8wcqe-PRuQnsdoPMomyvm"
                        ],
                        "style": {},
                        "id": "bmR_XnCBjHYx05CBBNhjO",
                        "key": "inline_bmR_XnCBjHYx05CBBNhjO"
                      }
                    ],
                    "style": {},
                    "id": "cAEv-3P2wzRxBzav6MZdf",
                    "key": "td_cAEv-3P2wzRxBzav6MZdf"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "2j03np61zXe7zVN0i_iRs",
                    "key": "td_2j03np61zXe7zVN0i_iRs"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "Awx6o8cRqi69DEOr1EbHk",
                    "key": "td_Awx6o8cRqi69DEOr1EbHk"
                  }
                ],
                "style": {},
                "id": "qymq7XjwhETSIp5bkTNuU",
                "key": "tr_qymq7XjwhETSIp5bkTNuU"
              },
              {
                "type": "tr",
                "columns": [
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "8MPg1eJ6iD_mPJF-MUvDM"
                        ],
                        "style": {},
                        "id": "J9MMMMnUa1SBDogLGNu-A",
                        "key": "inline_J9MMMMnUa1SBDogLGNu-A"
                      }
                    ],
                    "style": {},
                    "id": "QPtes4k2imNaP5wUqoM_t",
                    "key": "td_QPtes4k2imNaP5wUqoM_t"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "pE6LR5UsDGzSvQ3JkJ1ix",
                    "key": "td_pE6LR5UsDGzSvQ3JkJ1ix"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "tnfUZsOCZZh1obIF2X4NG",
                    "key": "td_tnfUZsOCZZh1obIF2X4NG"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "QoVaVK5tVXI3dwbAJ-zAq"
                        ],
                        "style": {},
                        "id": "SH8rH4VJrQMd9D81yYVh3",
                        "key": "inline_SH8rH4VJrQMd9D81yYVh3"
                      }
                    ],
                    "style": {},
                    "id": "lN39unTgaLqTfgIdks3Hw",
                    "key": "td_lN39unTgaLqTfgIdks3Hw"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "Ug2NLY_TfZ6KXYFFFKis9",
                    "key": "td_Ug2NLY_TfZ6KXYFFFKis9"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "LauoAB03gmP5qw5nz9Jxv",
                    "key": "td_LauoAB03gmP5qw5nz9Jxv"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "7JVD5Fzq_EomvEi8NVO5j"
                        ],
                        "style": {},
                        "id": "JpYTKP2TjbrCtcPK9Ek6l",
                        "key": "inline_JpYTKP2TjbrCtcPK9Ek6l"
                      }
                    ],
                    "style": {},
                    "id": "8jfCSpS7xj8WYTEQO1Zv2",
                    "key": "td_8jfCSpS7xj8WYTEQO1Zv2"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "UeaK1V8YYUOV3cuNEZvsT",
                    "key": "td_UeaK1V8YYUOV3cuNEZvsT"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "eceWgiScwr_7ZRYQp0rW-",
                    "key": "td_eceWgiScwr_7ZRYQp0rW-"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": false
                    },
                    "list": [
                      {
                        "type": "inline",
                        "columns": [
                          "Yjoe71hXFDbw93b3ukBS5"
                        ],
                        "style": {},
                        "id": "vw6eC7rnnrswg8dCX-6Bb",
                        "key": "inline_vw6eC7rnnrswg8dCX-6Bb"
                      }
                    ],
                    "style": {},
                    "id": "Te3MGXaN4RCd8sUYkuMWq",
                    "key": "td_Te3MGXaN4RCd8sUYkuMWq"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "CqDPbKExcT_IxeVtKi-Ln",
                    "key": "td_CqDPbKExcT_IxeVtKi-Ln"
                  },
                  {
                    "type": "td",
                    "options": {
                      "colspan": 3,
                      "rowspan": 1,
                      "isMerged": true
                    },
                    "list": [],
                    "style": {},
                    "id": "-8Xun9ZFqwm8U1mvYIYaa",
                    "key": "td_-8Xun9ZFqwm8U1mvYIYaa"
                  }
                ],
                "style": {},
                "id": "dc9X2Npd1SpSvuMyG2FyE",
                "key": "tr_dc9X2Npd1SpSvuMyG2FyE"
              }
            ],
            "options": {
              "width": 100,
              "widthType": "%"
            },
            "style": {
              "width": "100%"
            },
            "key": "table_6CNUjT70zEIhC_fWFtw8z"
          }
        ],
        "style": {},
        "id": "PpsmPtqpZQ59S8PZQOA6q",
        "key": "inline_PpsmPtqpZQ59S8PZQOA6q"
      }
    ],
    "mobile": [
      {
        "type": "inline",
        "columns": [
          "caFRuwlWKZjxx4AbJoSVv"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "i1nIAT9_R7uUfscmFYAnL"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "8JTtsbxm4TaWjBtmk4txy"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "8wcqe-PRuQnsdoPMomyvm"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "8MPg1eJ6iD_mPJF-MUvDM"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "QoVaVK5tVXI3dwbAJ-zAq"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "7JVD5Fzq_EomvEi8NVO5j"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "Yjoe71hXFDbw93b3ukBS5"
        ]
      }
    ]
  },
  "data": {},
  "config": {
    "isSync": true,
    "pc": {
      "size": "default",
      "labelPosition": "left",
      "completeButton": {
        "text": "提交",
        "color": "",
        "backgroundColor": ""
      }
    },
    "mobile": {
      "labelPosition": "left",
      "completeButton": {
        "text": "提交",
        "color": "",
        "backgroundColor": ""
      }
    }
  },
  "fields": [
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_caFRuwlWKZjxx4AbJoSVv",
      "id": "caFRuwlWKZjxx4AbJoSVv",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_i1nIAT9_R7uUfscmFYAnL",
      "id": "i1nIAT9_R7uUfscmFYAnL",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_8JTtsbxm4TaWjBtmk4txy",
      "id": "8JTtsbxm4TaWjBtmk4txy",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_8wcqe-PRuQnsdoPMomyvm",
      "id": "8wcqe-PRuQnsdoPMomyvm",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_8MPg1eJ6iD_mPJF-MUvDM",
      "id": "8MPg1eJ6iD_mPJF-MUvDM",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_QoVaVK5tVXI3dwbAJ-zAq",
      "id": "QoVaVK5tVXI3dwbAJ-zAq",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_7JVD5Fzq_EomvEi8NVO5j",
      "id": "7JVD5Fzq_EomvEi8NVO5j",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_Yjoe71hXFDbw93b3ukBS5",
      "id": "Yjoe71hXFDbw93b3ukBS5",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    }
  ]
}

let fieldArr = [
  {
    span: 24,
    field: "email",
    type: "input",
    label: "单行文本",
    icon: "input",
    key: "input_8wcqe-PRuQnsdoPMomyvm",
    id: "8wcqe-PRuQnsdoPMomyvm",
    options: {
      clearable: true,
      isShowWordLimit: false,
      renderType: 1,
      disabled: false,
      showPassword: false,
      defaultValue: "",
      placeholder: "请输入",
      labelWidth: 100,
    },
    style: {
      width: {
        pc: "100%",
        mobile: "100%"
      }
    }
  },
  {
    field: "age",
    type: "input",
    label: "单行文本",
    icon: "input",
    key: "input_8wcqe-PRuQnsdoPMomyvm",
    id: "8wcqe-PRuQnsdoPMomyvm",
    options: {
      clearable: true,
      isShowWordLimit: false,
      renderType: 1,
      disabled: false,
      showPassword: false,
      defaultValue: "",
      placeholder: "请输入",
      labelWidth: 100,
    },
    style: {
      width: {
        pc: "100%",
        mobile: "100%"
      }
    }
  },
  {
    field: "name",
    type: "input",
    label: "单行文本",
    icon: "input",
    key: "input_8wcqe-PRuQnsdoPMomyvm",
    id: "8wcqe-PRuQnsdoPMomyvm",
    options: {
      clearable: true,
      isShowWordLimit: false,
      renderType: 1,
      disabled: false,
      showPassword: false,
      defaultValue: "",
      placeholder: "请输入",
      labelWidth: 100,
    },
    style: {
      width: {
        pc: "100%",
        mobile: "100%"
      }
    }
  },
  {
    field: "email",
    type: "input",
    label: "单行文本",
    icon: "input",
    key: "input_8wcqe-PRuQnsdoPMomyvm",
    id: "8wcqe-PRuQnsdoPMomyvm",
    options: {
      clearable: true,
      isShowWordLimit: false,
      renderType: 1,
      disabled: false,
      showPassword: false,
      defaultValue: "",
      placeholder: "请输入",
      labelWidth: 100,
    },
    style: {
      width: {
        pc: "100%",
        mobile: "100%"
      }
    }
  }, {
    field: "email",
    type: "input",
    label: "单行文本",
    icon: "input",
    key: "input_8wcqe-PRuQnsdoPMomyvm",
    id: "8wcqe-PRuQnsdoPMomyvm",
    options: {
      clearable: true,
      isShowWordLimit: false,
      renderType: 1,
      disabled: false,
      showPassword: false,
      defaultValue: "",
      placeholder: "请输入",
      labelWidth: 100,
    },
    style: {
      width: {
        pc: "100%",
        mobile: "100%"
      }
    }
  }
]

export const formConfig = {
  items: fieldArr,
  data: {}
}






export const testData1 = {
  "layout": {
    "pc": [
      {
        "type": "inline",
        "columns": [
          "NvExu6Re6uRIVMgxnnWgB"
        ],
        "style": {},
        "id": "ScXkQTnYEl2Yf0988YPBg",
        "key": "inline_ScXkQTnYEl2Yf0988YPBg"
      },
      {
        "type": "inline",
        "columns": [
          {
            "type": "grid",
            "label": "栅格布局",
            "icon": "grid",
            "id": "kfgkpJhCt_4MuTSwU6uSy",
            "columns": [
              {
                "id": "THhJJHB9FXu4Pc37jeq6S",
                "options": {
                  "span": 6,
                  "offset": 0,
                  "pull": 0,
                  "push": 0
                },
                "type": "col",
                "list": [
                  {
                    "type": "inline",
                    "columns": [
                      "r6hNllBugy4l9IijZ6akr"
                    ],
                    "style": {},
                    "id": "np3_ZFEhTK0kpb6YlpdD1",
                    "key": "inline_np3_ZFEhTK0kpb6YlpdD1"
                  }
                ],
                "style": {},
                "key": "col_THhJJHB9FXu4Pc37jeq6S"
              },
              {
                "id": "0rVaPXcAc8LQuvACRc9CO",
                "options": {
                  "span": 6,
                  "offset": 0,
                  "pull": 0,
                  "push": 0
                },
                "type": "col",
                "list": [
                  {
                    "type": "inline",
                    "columns": [
                      {
                        "type": "grid",
                        "label": "栅格布局",
                        "icon": "grid",
                        "id": "FYBr8vZUnyzUu0jwEh60O",
                        "columns": [
                          {
                            "id": "lucUF_w1ojfobuPHXZfp4",
                            "options": {
                              "span": 6,
                              "offset": 0,
                              "pull": 0,
                              "push": 0
                            },
                            "type": "col",
                            "list": [
                              {
                                "type": "inline",
                                "columns": [
                                  "SfWRLacWt4CekAOvVaOAy"
                                ],
                                "style": {},
                                "id": "zRaAIjYFkDmLcNdpFRO2A",
                                "key": "inline_zRaAIjYFkDmLcNdpFRO2A"
                              }
                            ],
                            "style": {},
                            "key": "col_lucUF_w1ojfobuPHXZfp4"
                          },
                          {
                            "id": "gKO_iidheyRmh8HB2KmVJ",
                            "options": {
                              "span": 6,
                              "offset": 0,
                              "pull": 0,
                              "push": 0
                            },
                            "type": "col",
                            "list": [],
                            "style": {},
                            "key": "col_gKO_iidheyRmh8HB2KmVJ"
                          },
                          {
                            "id": "_HBtzNATjkrz-Ki7ibfyl",
                            "options": {
                              "span": 6,
                              "offset": 0,
                              "pull": 0,
                              "push": 0
                            },
                            "type": "col",
                            "list": [],
                            "style": {},
                            "key": "col__HBtzNATjkrz-Ki7ibfyl"
                          }
                        ],
                        "options": {
                          "gutter": 0,
                          "justify": "space-around",
                          "align": "top"
                        },
                        "style": {
                          "width": "142%"
                        },
                        "key": "grid_FYBr8vZUnyzUu0jwEh60O"
                      }
                    ],
                    "style": {},
                    "id": "6eQ1PwVlfGTRqM_lfVmHi",
                    "key": "inline_6eQ1PwVlfGTRqM_lfVmHi"
                  }
                ],
                "style": {},
                "key": "col_0rVaPXcAc8LQuvACRc9CO"
              },
              {
                "id": "gycRCrNJilkjr4WIsOQ8J",
                "options": {
                  "span": 6,
                  "offset": 0,
                  "pull": 0,
                  "push": 0
                },
                "type": "col",
                "list": [],
                "style": {},
                "key": "col_gycRCrNJilkjr4WIsOQ8J"
              }
            ],
            "options": {
              "gutter": 0,
              "justify": "space-around",
              "align": "top"
            },
            "style": {
              "width": "100%"
            },
            "key": "grid_kfgkpJhCt_4MuTSwU6uSy"
          }
        ],
        "style": {},
        "id": "mXRnE_gweMtYpEPev1f2x",
        "key": "inline_mXRnE_gweMtYpEPev1f2x"
      }
    ],
    "mobile": [
      {
        "type": "inline",
        "columns": [
          "NvExu6Re6uRIVMgxnnWgB"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "r6hNllBugy4l9IijZ6akr"
        ]
      },
      {
        "type": "inline",
        "columns": [
          "SfWRLacWt4CekAOvVaOAy"
        ]
      }
    ]
  },
  "data": {},
  "config": {
    "isSync": true,
    "pc": {
      "size": "default",
      "labelPosition": "left",
      "completeButton": {
        "text": "提交",
        "color": "",
        "backgroundColor": ""
      }
    },
    "mobile": {
      "labelPosition": "left",
      "completeButton": {
        "text": "提交",
        "color": "",
        "backgroundColor": ""
      }
    }
  },
  "fields": [
    {
      "type": "Sform",//
      "label": "单行文本",
      "icon": "input",
      field: "email",
      "key": "input_NvExu6Re6uRIVMgxnnWgB",
      "id": "NvExu6Re6uRIVMgxnnWgB",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      "type": "input",
      "label": "单行文本",
      field: "name",
      "icon": "input",
      "key": "input_r6hNllBugy4l9IijZ6akr",
      "id": "r6hNllBugy4l9IijZ6akr",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    },
    {
      field: 'password',
      "type": "input",
      "label": "单行文本",
      "icon": "input",
      "key": "input_SfWRLacWt4CekAOvVaOAy",
      "id": "SfWRLacWt4CekAOvVaOAy",
      "options": {
        "clearable": true,
        "isShowWordLimit": false,
        "renderType": 1,
        "disabled": false,
        "showPassword": false,
        "defaultValue": "",
        "placeholder": "请输入",
        "labelWidth": 100,
        "isShowLabel": true,
        "required": false,
        "min": null,
        "max": null
      },
      "style": {
        "width": {
          "pc": "100%",
          "mobile": "100%"
        }
      }
    }
  ]
}