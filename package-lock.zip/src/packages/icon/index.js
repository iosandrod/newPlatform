// import '../theme/icon/index.scss'
import Icon from './index.vue'
export default Icon
