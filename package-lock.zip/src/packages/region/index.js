import './style/index.js'
import EverrightRegion from './index.vue'
export {
  EverrightRegion
}
