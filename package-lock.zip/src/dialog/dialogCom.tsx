import { defineComponent } from 'vue'

export default defineComponent({
  name: 'DialogCom',
  props: {},
  setup() {
    return () => {
      return <div></div>
    }  
  },
}) //
