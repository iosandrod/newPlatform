
declare module 'vue' {
  export interface ComponentCustomProperties {

  }
}
declare module 'vue-router' {
  interface RouteMeta {
   
  }
}

export {};
