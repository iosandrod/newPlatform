import { defineComponent } from "vue";

export default defineComponent({
    name: "buttonCom",
    setup() {
        return () => <div>button</div>;
    },
});